// serveur.c
#include "pse.h"

#define CMD           "serveur"
#define NOM_JOURNAL   "journal.log"
#define NB_WORKERS    50 

void creerCohorteWorkers(void);
int chercherWorkerLibre(void);
void *threadWorker(void *arg);
void sessionClient(int canal);
int ecrireJournal(char *ligne);
void remiseAZeroJournal(void);

// appelent les fonctions systeme correspondantes + exit si echec
void init_semaphore(sem_t *sem, int valeur);
void wait_semaphore(sem_t *sem);
void post_semaphore(sem_t *sem);
void lock_mutex(pthread_mutex_t *mutex);
void unlock_mutex(pthread_mutex_t *mutex);

// acces au canal d'un worker : le thread principal et un worker peuvent
// acceder simultanement au canal du worker (lors de la recherche d'un worker
// libre pour l'un, lors de la remise du canal a -1 pour l'autre)
// => utilisation d'un mutex par worker; on l'ajoute dans la structure DataSpec

// acces au descripteur du journal : un worker qui ecrit dans le journal et un
// autre qui remet le journal a zero peuvent acceder simultanement au
// descripteur du journal
// => utilisation d'un mutex

int fdJournal;
pthread_mutex_t mutexJournal = PTHREAD_MUTEX_INITIALIZER;
DataSpec dataWorkers[NB_WORKERS];
sem_t semWorkersLibres;

int main(int argc, char *argv[]) {
  short port;
  int ecoute, canal, ret;
  struct sockaddr_in adrEcoute, adrClient;
  unsigned int lgAdrClient;
  int numWorkerLibre;

  if (argc != 2)
    erreur("usage: %s port\n", argv[0]);

  fdJournal = open(NOM_JOURNAL, O_CREAT|O_WRONLY|O_APPEND, 0600);
  if (fdJournal == -1)
    erreur_IO("ouverture journal");

  port = (short)atoi(argv[1]);

  creerCohorteWorkers();
  init_semaphore(&semWorkersLibres, NB_WORKERS);

  printf("%s: creating a socket\n", CMD);
  ecoute = socket (AF_INET, SOCK_STREAM, 0);
  if (ecoute < 0)
    erreur_IO("socket");
  
  adrEcoute.sin_family = AF_INET;
  adrEcoute.sin_addr.s_addr = INADDR_ANY;
  adrEcoute.sin_port = htons(port);
  printf("%s: binding to INADDR_ANY address on port %d\n", CMD, port);
  ret = bind (ecoute,  (struct sockaddr *)&adrEcoute, sizeof(adrEcoute));
  if (ret < 0)
    erreur_IO("bind");
  
  printf("%s: listening to socket\n", CMD);
  ret = listen (ecoute, 5);
  if (ret < 0)
    erreur_IO("listen");
  
  while (VRAI) {
    printf("%s: accepting a connection\n", CMD);
    lgAdrClient = sizeof(adrClient);
    canal = accept(ecoute, (struct sockaddr *)&adrClient, &lgAdrClient);
    if (canal < 0)
    erreur_IO("accept");

    printf("%s: adr %s, port %hu\n", CMD,
          stringIP(ntohl(adrClient.sin_addr.s_addr)),
          ntohs(adrClient.sin_port));

    sem_wait(&semWorkersLibres);
    numWorkerLibre = chercherWorkerLibre();
    dataWorkers[numWorkerLibre].canal = canal;
    post_semaphore(&dataWorkers[numWorkerLibre].sem);
  }

  if (close(ecoute) == -1)
    erreur_IO("fermeture socket ecoute");  

  if (close(fdJournal) == -1)
    erreur_IO("fermeture journal");  

  exit(EXIT_SUCCESS);
}

void creerCohorteWorkers(void) {
  int i;
  int ret;

  for (i = 0; i < NB_WORKERS; i++) {
    dataWorkers[i].canal = -1;
    dataWorkers[i].tid = i;
    init_semaphore(&dataWorkers[i].sem, 0);

    ret = pthread_mutex_init(&dataWorkers[i].mutex, NULL);
    if (ret != 0)
      erreur_IO("init mutex");

    ret = pthread_create(&dataWorkers[i].id, NULL, threadWorker,
                         &dataWorkers[i]);
    if (ret != 0)
      erreur_IO("creation worker");
  }
}

// retourne le numero du worker libre trouve ou -1 si pas de worker libre
int chercherWorkerLibre(void) {
  int i;
  int canal;

  for (i = 0; i < NB_WORKERS; i++) {
    lock_mutex(&dataWorkers[i].mutex);
    canal = dataWorkers[i].canal;
    unlock_mutex(&dataWorkers[i].mutex);

    if (canal == -1)
      return i;
  }

  return -1;
}

void *threadWorker(void *arg) {
  DataSpec *dataSpec = (DataSpec *)arg;

  while (VRAI) {
    wait_semaphore(&dataSpec->sem);
    printf("worker %d: reveil\n", dataSpec->tid);

    sessionClient(dataSpec->canal);

    printf("worker %d: sommeil\n", dataSpec->tid);
    lock_mutex(&dataSpec->mutex);
    dataSpec->canal = -1;
    unlock_mutex(&dataSpec->mutex);

    post_semaphore(&semWorkersLibres);
  }

  pthread_exit(NULL);
}

// session d'echanges avec un client
// fermeture du canal a la fin de la session
void sessionClient(int canal) {
  int fin = FAUX;
  char ligne[LIGNE_MAX];
  int lgLue, lgEcr;

  while (!fin) {
    lgLue = lireLigne(canal, ligne);
    if (lgLue == -1)
      erreur_IO("lecture ligne");

    if (lgLue == 0) { // connexion fermee, donc arret du client
      printf("serveur: arret du client\n");
      fin = VRAI;
    }
    else if (strcmp(ligne, "fin") == 0) {
      printf("serveur: fin demandee\n");
      fin = VRAI;
    }
    else if (strcmp(ligne, "init") == 0) {
      printf("serveur: remise a zero du journal\n");
      remiseAZeroJournal();
    }
    else {
      lgEcr = ecrireJournal(ligne); 
      if (lgEcr == -1)
        erreur_IO("ecriture journal");
      printf("serveur: ligne de %d octets ecrite dans le journal\n", lgEcr);
    }
  }

  if (close(canal) == -1)
    erreur_IO("fermeture canal");  
}

int ecrireJournal(char *ligne) {
  int lg;

  lock_mutex(&mutexJournal);
  lg = ecrireLigne(fdJournal, ligne); 
  unlock_mutex(&mutexJournal);

  return lg;
}

void remiseAZeroJournal(void) {
  // on ferme le fichier et on le rouvre en mode O_TRUNC
  lock_mutex(&mutexJournal);
  if (close(fdJournal) == -1)
    erreur_IO ("fermeture jornal pour remise a zero");

  fdJournal = open(NOM_JOURNAL, O_TRUNC|O_WRONLY|O_APPEND, 0600);
  if (fdJournal == -1)
    erreur_IO ("ouverture journal pour remise a zero");
  unlock_mutex(&mutexJournal);
}

void init_semaphore(sem_t *sem, int valeur) {
  int ret;
  ret = sem_init(sem, 0, valeur);
  if (ret != 0)
   erreur_IO("init semaphore");
}

void wait_semaphore(sem_t *sem) {
  int ret;
  ret = sem_wait(sem);
  if (ret != 0)
   erreur_IO("wait semaphore");
}

void post_semaphore(sem_t *sem) {
  int ret;
  ret = sem_post(sem);
  if (ret != 0)
   erreur_IO("post semaphore");
}

void lock_mutex(pthread_mutex_t *mutex) {
  int ret;
  ret = pthread_mutex_lock(mutex);
  if (ret != 0)
    erreur_IO("lock mutex");
}

void unlock_mutex(pthread_mutex_t *mutex) {
  int ret;
  ret = pthread_mutex_unlock(mutex);
  if (ret != 0)
    erreur_IO("unlock mutex");
}
