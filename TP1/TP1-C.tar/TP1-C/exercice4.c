#include "pse.h"

int main(int argc, char *argv[]) {
  /* requete DNS */
  struct sockaddr_in *adresse;

  adresse = resolv(argv[1], argv[2]);
  if (adresse == NULL)
    exit(EXIT_FAILURE);

  printf("adr: %s\n", stringIP(ntohl(adresse->sin_addr.s_addr)));
  printf("port: %d\n", ntohs(adresse->sin_port));

  exit(EXIT_SUCCESS);
}
