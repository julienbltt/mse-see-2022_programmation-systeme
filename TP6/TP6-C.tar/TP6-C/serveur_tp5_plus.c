// serveur_tp5_plus.c
// version du serveur du TP5 liberant les maillons
// evolution : la fonction du thread recoit en argument un pointeur de type
// DataThread (le maillon), pour qu'elle puisse appeler avant de se terminer
// la fonction supprimerDataThread qui supprime le maillon de la liste et
// libere sa memoire;
// la fonction supprimerDataThread est dans serveur.c, il faudrait la transferer
// dans le module datathread.c
#include "pse.h"

#define CMD           "serveur"
#define NOM_JOURNAL   "journal.log"

void *threadSessionClient(void *arg);
void sessionClient(int canal);
void supprimerDataThread(DataThread *dataThread);
void remiseAZeroJournal(void);

int fdJournal;

int main(int argc, char *argv[]) {
  short port;
  int ecoute, canal, ret;
  struct sockaddr_in adrEcoute, adrClient;
  unsigned int lgAdrClient;
  DataThread *dataThread;

  if (argc != 2)
    erreur("usage: %s port\n", argv[0]);

  fdJournal = open(NOM_JOURNAL, O_CREAT|O_WRONLY|O_APPEND, 0600);
  if (fdJournal == -1)
    erreur_IO("ouverture journal");

  port = (short)atoi(argv[1]);

  initDataThread();

  printf("%s: creating a socket\n", CMD);
  ecoute = socket (AF_INET, SOCK_STREAM, 0);
  if (ecoute < 0)
    erreur_IO("socket");
  
  adrEcoute.sin_family = AF_INET;
  adrEcoute.sin_addr.s_addr = INADDR_ANY;
  adrEcoute.sin_port = htons(port);
  printf("%s: binding to INADDR_ANY address on port %d\n", CMD, port);
  ret = bind (ecoute,  (struct sockaddr *)&adrEcoute, sizeof(adrEcoute));
  if (ret < 0)
    erreur_IO("bind");
  
  printf("%s: listening to socket\n", CMD);
  ret = listen (ecoute, 5);
  if (ret < 0)
    erreur_IO("listen");
  
  while (VRAI) {
    printf("%s: accepting a connection\n", CMD);
    lgAdrClient = sizeof(adrClient);
    canal = accept(ecoute, (struct sockaddr *)&adrClient, &lgAdrClient);
    if (canal < 0)
    erreur_IO("accept");

    printf("%s: adr %s, port %hu\n", CMD,
          stringIP(ntohl(adrClient.sin_addr.s_addr)),
          ntohs(adrClient.sin_port));

    dataThread = ajouterDataThread();
    dataThread->spec.canal = canal;
    ret = pthread_create(&dataThread->spec.id, NULL, threadSessionClient, 
                         dataThread);
    if (ret != 0)
      erreur_IO("creation thread");
  }

  if (close(ecoute) == -1)
    erreur_IO("fermeture socket ecoute");  

  if (close(fdJournal) == -1)
    erreur_IO("fermeture journal");  

  exit(EXIT_SUCCESS);
}

void *threadSessionClient(void *arg) {
  DataThread *dataThread = (DataThread *)arg;

  sessionClient(dataThread->spec.canal);
  supprimerDataThread(dataThread);

  pthread_exit(NULL);
}

// session d'echanges avec un client
// fermeture du canal a la fin de la session
void sessionClient(int canal) {
  int fin = FAUX;
  char ligne[LIGNE_MAX];
  int lgLue, lgEcr;

  while (!fin) {
    lgLue = lireLigne(canal, ligne);
    if (lgLue == -1)
      erreur_IO("lecture ligne");

    if (lgLue == 0) { // connexion fermee, donc arret du client
      printf("serveur: arret du client\n");
      fin = VRAI;
    }
    else if (strcmp(ligne, "fin") == 0) {
      printf("serveur: fin demandee\n");
      fin = VRAI;
    }
    else if (strcmp(ligne, "init") == 0) {
      printf("serveur: remise a zero du journal\n");
      remiseAZeroJournal();
    }
    else {
      lgEcr = ecrireLigne(fdJournal, ligne); 
      if (lgEcr == -1)
        erreur_IO("ecriture journal");
      printf("serveur: ligne de %d octets ecrite dans le journal\n", lgEcr);
    }
  }

  if (close(canal) == -1)
    erreur_IO("fermeture canal");  
}

void supprimerDataThread(DataThread *dataThread) {
  DataThread *maillon;
  DataThread *prec;

  maillon = listeDataThread;
  prec = NULL;

  // recherche du maillon dataThread dans la liste en gardant trace de son
  // precedent
  while (maillon != NULL && maillon != dataThread) {
    prec = maillon;
    maillon = maillon->next;
  }

  if (maillon == NULL) // ne devrait pas arriver
    printf("maillon non trouve\n");
  else {
    if (prec == NULL) // le maillon a supprimer est le premier de la liste
      listeDataThread = maillon->next;
    else
      prec->next = maillon->next;
    free(maillon);
  }
}

void remiseAZeroJournal(void) {
  // on ferme le fichier et on le rouvre en mode O_TRUNC
  if (close(fdJournal) == -1)
    erreur_IO ("fermeture jornal pour remise a zero");

  fdJournal = open(NOM_JOURNAL, O_TRUNC|O_WRONLY|O_APPEND, 0600);
  if (fdJournal == -1)
    erreur_IO ("ouverture journal pour remise a zero");
}
