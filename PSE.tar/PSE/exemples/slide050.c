if (close (fle) == -1) { /* fle : cf. slide046.c */
  perror ("close");
  exit (EXIT_FAILURE);
 }
