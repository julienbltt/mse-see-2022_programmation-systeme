pid_t monpid = getpid ();
pid_t papa = getppid ();
printf ("Mon numero est %d et celui de papa est %d\n", monpid, papa);
